document.addEventListener ('DOMContentLoaded', async () => {

    const estudiantesContainer = document.getElementById('student-list');
    const template = document.getElementById('student-card-template');

    try {

        const students = await api.getStudents();

        students.forEach(student => {

            const studentCard = template.content.cloneNode(true);

            studentCard.querySelector('.student-photo').src = student.photo;
            studentCard.querySelector('.student-name').textContent = student.name;
            studentCard.querySelector('.student-email').textContent = student.email;
            studentCard.querySelector('.student-code').textContent = `ID: ${student.code}`;
            studentCard.querySelector('.student-description').textContent = student.description;
            
            studentCard.querySelector('.student-github').addEventListener('click', () => {

                window.open(student.github_link, '_blank');

            });

            estudiantesContainer.appendChild(studentCard);

        });

    } catch(error) {

        console.error('Error cargando los estudiantes:', error);
        estudiantesContainer.innerHTML = '<p>Error al cargar los estudiantes.</p>';

    }

});
document.addEventListener('DOMContentLoaded', async () => {
    // Sample student data
    
    /*const students = [
        {
            name: 'Carlos Rene Angarita Sanguino',
            id: '05372',
            email: 'carlosreneas@ufps.edu.co',
            github: 'cesarcamiloig',
            image: 'linux.png'
        },
        {
            name: 'Yan Carlo Angarita Sanguino',
            id: '00001',
            email: 'yancarlo120b@gmail.com',
            github: 'cesarcamiloig',
            image: 'linux.png'
        },
        {
            name: 'Claudia Yamile Gomez Llanez',
            id: '05096',
            email: 'claudiaygomez@ufps.edu.co',
            github: 'cesarcamiloig',
            image: 'linux.png'
        },
        
    ];*/

    const studentsList = document.getElementById('studentsList');
    const template = document.getElementById('studentCardTemplate');

    // Render students
    async function renderStudents() {
        const students = await api.getStudents();
        studentsList.innerHTML = '';
        students.forEach(student => {

            console.log(student);

            
            const clone = template.content.cloneNode(true);
            clone.querySelector('.student-name').textContent = student.name;
            clone.querySelector('.student-id').textContent = `ID: ${student.code}`;
            clone.querySelector('.student-email').textContent = student.email;
            clone.querySelector('.student-image').src = student.photo;
            clone.querySelector('.github').href = student.github_link;

            studentsList.appendChild(clone);
            
        });
    }

    // Initial render
    await renderStudents();

});
